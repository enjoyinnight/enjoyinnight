# Google Drive Image Upload — Setup Guide

This site stores all product **data** as JSON in `localStorage` (no backend).
For product **images**, you have two options out of the box:

1. **Local upload (works immediately, zero setup):** in the admin "Add Product"
   form, choosing a file with the file picker stores the image as a base64
   data URL alongside the product. Nothing else to configure.
2. **Google Drive upload (optional, for real hosting of images):** follow the
   steps below to let the admin upload images directly to a Google Drive
   folder and store the public Drive URL instead.

Drive integration lives entirely in `js/drive-upload.js`.

---

## 1. Create a Google Cloud Project

1. Go to https://console.cloud.google.com/
2. Click the project dropdown → **New Project**.
3. Name it (e.g. "Bazar Marketplace") and click **Create**.

## 2. Enable the Google Drive API

1. In the Cloud Console, open **APIs & Services → Library**.
2. Search for **Google Drive API** → click **Enable**.
3. Also enable **Google Picker API** (search and enable) if you want the
   "pick an existing Drive file" feature.

## 3. Create OAuth 2.0 Credentials

1. Go to **APIs & Services → Credentials**.
2. Click **Create Credentials → OAuth client ID**.
3. If prompted, configure the **OAuth consent screen** first:
   - User type: External (or Internal if using Google Workspace)
   - Fill in app name, support email
   - Add your domain (or `localhost` for testing) to authorized domains
   - Add the scope: `https://www.googleapis.com/auth/drive.file`
4. Back in **Create OAuth client ID**:
   - Application type: **Web application**
   - Authorized JavaScript origins: add the URL(s) where the site is hosted,
     e.g. `http://localhost:5500` and `https://yourdomain.com`
   - Click **Create**
5. Copy the generated **Client ID**.

## 4. Create an API Key

1. Still in **Credentials**, click **Create Credentials → API key**.
2. Copy the generated key.
3. (Recommended) Click **Restrict key** → restrict it to the Google Drive API
   and to your site's HTTP referrers.

## 5. Create and Configure the Destination Folder

1. In Google Drive, create a folder (e.g. "Bazar Product Images").
2. Open the folder and copy the **Folder ID** from the URL:
   `https://drive.google.com/drive/folders/<FOLDER_ID>`
3. Right-click the folder → **Share** → set to anyone with the link can
   **Viewer**, so uploaded images can be displayed publicly on the site.
   (Individual files are also set to "anyone with the link, Viewer"
   automatically by the upload code — see step 6.)

## 6. Plug the Values into the Code

Open `js/drive-upload.js` and fill in the `DRIVE_CONFIG` object at the top:

```js
const DRIVE_CONFIG = {
  CLIENT_ID: "123456789-abc.apps.googleusercontent.com", // from step 3
  API_KEY:   "AIzaSy...",                                 // from step 4
  APP_ID:    "123456789",                                  // your Cloud project number
  FOLDER_ID: "1AbCDefGhIJKlmnoPQRstuVWxyz",                 // from step 5
  SCOPE:     "https://www.googleapis.com/auth/drive.file"
};
```

That's it — no other code changes needed. The logic already:

- Loads `apis.google.com/js/api.js` and `accounts.google.com/gsi/client`
  dynamically (`loadDriveLibraries`)
- Signs the admin in with Google Identity Services (`signInToGoogle`)
- Uploads the chosen file to your folder via a multipart request to
  `POST https://www.googleapis.com/upload/drive/v3/files` (`uploadImageToDrive`)
- Sets the file's permission to "anyone with the link can view"
- Returns a direct image URL in the form:
  `https://drive.google.com/uc?export=view&id=<FILE_ID>`
- Optionally opens the Google Picker so the admin can re-use an existing
  Drive image (`pickImageFromDrive`)

## 7. Using It in the Admin Panel

On the **Add/Edit Product** page:

1. Choose a file with the file input (this is the fallback / preview).
2. Click **"Upload selected file to Google Drive instead"**.
3. The first time, a Google sign-in popup appears — sign in with the Google
   account that owns the Drive folder.
4. Once uploaded, the image preview updates to the live Drive URL and that
   URL is what gets saved with the product.

If `DRIVE_CONFIG` is left with its placeholder `YOUR_...` values, the button
shows a friendly message and the form simply uses the local file (base64)
instead — so the whole project still works perfectly without any Google
setup, which is great for quick demos.

## Notes & Limits

- `https://drive.google.com/uc?export=view&id=...` works for direct `<img>`
  embedding for files shared as "anyone with the link."
- The OAuth scope used (`drive.file`) only lets the app see/manage files
  *it* creates — it cannot browse the admin's entire Drive, which is good
  practice for a third-party web app.
- Access tokens from Google Identity Services are short-lived; if uploads
  start failing after a long idle period, the code will silently prompt for
  sign-in again on the next upload attempt.
