# Bazar — Pure HTML/CSS/JS Product Marketplace

A Flipkart-style product marketplace built with **only HTML, CSS, and
JavaScript** — no PHP/Node/Python backend. All data lives in the browser via
`localStorage`; product images can be plain uploads (stored as base64) or
real Google Drive-hosted images (see `README-google-drive-setup.md`).

## Running it

No build step. Just open `index.html` in a browser, or serve the folder with
any static server (recommended, so the Google Drive OAuth flow works):

```bash
npx serve .
# or
python -m http.server 5500
```

Then visit `http://localhost:5500`.

## File structure

```
index.html                    Public homepage — grid, search, city filter, detail modal
product.html                  Standalone full-page product detail (open via ?id=<productId>)
admin.html                    Admin login screen
admin-dashboard.html          Admin: product list (view/edit/delete) + stats
admin-product-form.html       Admin: add/edit product form (+ image upload)
admin-settings.html           Admin: branding settings + change login credentials

css/
 ├─ style.css                 Design tokens, public site layout, components, themes
 └─ admin.css                 Admin shell, tables, forms, login screen

js/
 ├─ app.js                    Public site: product data layer, rendering, search/filter,
 │                            detail modal, WhatsApp link builder
 ├─ admin.js                  Admin: auth, product CRUD, settings form, image handling
 ├─ drive-upload.js           Google Drive OAuth2 + Picker + upload integration
 └─ settings.js               Site branding (name/logo/title) + dark/light theme, shared
                              by every page so admin changes appear everywhere instantly

README-google-drive-setup.md  Step-by-step Google Cloud / Drive API setup guide
```

## How the public site works (`app.js`)

- **Data layer:** `getProducts()` / `saveProducts()` read and write a single
  `bazar_products` key in `localStorage`, seeded with 6 demo listings the
  first time the site runs.
- **Search & filter:** typing in the search box filters by product name
  (case-insensitive); clicking a city "chip" filters by city. Both combine.
- **Grid:** `renderProductGrid()` builds the responsive CSS Grid of cards
  (image, name, price, city) from the filtered product list.
- **Detail modal:** clicking/tapping a card calls `openProductModal(id)`,
  which fills in the modal with image, name, age, price, city, address,
  description, and builds the WhatsApp button link.
- **WhatsApp button:** `buildWhatsAppLink(product)` constructs
  `https://wa.me/<number>?text=<encoded message>` with the product's name,
  price, and image URL pre-filled in the message, exactly as required.

## How the admin panel works (`admin.js`)

- **Login:** credentials are stored in `localStorage` under
  `bazar_admin_creds` (default `admin` / `admin123`), checked against the
  login form. A session flag in `sessionStorage` gates the dashboard pages
  (`data-require-auth="true"` on `<body>`).
- **CRUD:** the dashboard table reads the same `bazar_products` localStorage
  key used by the public site. Add/Edit uses one shared form
  (`admin-product-form.html`); Delete asks for confirmation, then re-saves
  the array without that product. Because both admin and public pages read
  the same key, **changes appear immediately** the next time the public site
  loads (and live, in another open tab, via the `storage` event).
- **Images:** the form lets the admin either (a) pick a local file, which is
  embedded as a base64 data URL — zero setup required — or (b) click
  "Upload to Google Drive," which uses `drive-upload.js` to upload the file
  to a configured Drive folder and store the public Drive URL + file ID
  instead. See `README-google-drive-setup.md` for full setup steps.
- **Settings:** `admin-settings.html` writes to a `bazar_settings`
  localStorage key (site name, header tagline, logo). `settings.js` is
  loaded on *every* page and re-applies these values to any element tagged
  `data-bind="siteName"` / `data-bind="headerTitle"` / `data-bind="logo"`,
  so admin changes show up across the whole site instantly.

## Data shape

Each product is stored as:

```json
{
  "id": "p1",
  "name": "iPhone 14",
  "age": "6 Months",
  "price": "50000",
  "city": "Delhi",
  "address": "Kalkaji, New Delhi",
  "description": "Excellent condition",
  "whatsapp": "919999999999",
  "imageUrl": "https://drive.google.com/uc?export=view&id=...",
  "driveFileId": "..."
}
```

## Design

The visual direction ("Market Ledger") pairs a warm paper background with a
deep teal brand color and an amber price accent, a serif display face
(Fraunces) for headings against a clean Inter body face, and a subtle
diagonal ledger-line texture in the hero. Built with CSS variables throughout
so the dark theme (toggle in the header) and any future re-skin via Settings
only require touching tokens, not component code. Fully responsive: grid
columns reflow with `auto-fill`/`minmax`, the header collapses the search bar
to its own row on mobile, and the product modal stacks to a single column
under 700px.

## Notes on the demo/limits

- This is a client-only demo: anyone with browser dev tools can see the
  `bazar_admin_creds` value. Don't use this auth approach for anything that
  needs real security — a backend with hashed passwords is required for that.
- `localStorage` is per-browser/per-device; there is no multi-device sync
  without adding a real backend or a sync service.
